<?php
//conexion a la base de donnee
$host = "localhost";
$db = "tp-1";
$user = "root";
$password = "";
$dns = "mysql:host=$host;dbname=$db;charset=UTF8";
try{
    $oPDO = new PDO($dns,$user,$password);
    if($oPDO){
        echo"connected to $db databse successfully ";
    }
}catch(PDOExeption $e){
    echo $e->getMessage();
}
require_once "class/Thermometre.php";

//utilsation de la methode getThermometre
$thrmo = new Thermometre;
echo "<br>";
echo "<br>";
var_dump($thrmo->getThermometre(1));
echo "<br>";
echo "<br>";

//utilsation de la methode createThermometre
$thrmo1 = new Thermometre;
$thrmo1->createThermometre(5,"pinto",22,"frontale");
echo "<br>";
echo "<br>";
var_dump($thrmo1->getThermometre(5));

// utilsation de la methode deleteThermometre()pour suprimer un thermometre sur notre base de donne
echo "<br>";
echo "<br>";
var_dump($thrmo->deleteThermometre(5));

echo "<br>";
echo "<br>";

// $thrmo1->createThermometre(5,"pinto",22,"frontale");
  

//utilisation la methode getThermometres qui retourne toute la liste

$thrmo2 = new Thermometre;
echo "<br>";
echo "<br>";
var_dump($thrmo2->getThermometres());

//utilisation la methode getThermometreByMarque qui retourne toute la liste par marque
$thrmo3 = new Thermometre;
var_dump($thrmo3->getThermometreByMarque('physio logic'));
echo "<br>";
echo "<br>";

//utilisation la methode getThermometreByMarque pour modifier par son id
$thrmo = new Thermometre;


$thrmo = $othrmo->getThermometre(1);

$thrmo['marque'] = "tchikou";
$thrmo['prix'] = 50;
$thrmo['type'] = 'rectale';
$thrmo->UpdateLivre($thrmo['id'],$thrmo);

//affichage des nouvelles donnees modifier
var_dump($othrmo->getThermometre(1));
?>