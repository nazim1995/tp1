-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 27 sep. 2023 à 01:38
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tp-1`
--

-- --------------------------------------------------------

--
-- Structure de la table `thermomètre`
--

CREATE TABLE `thermomètre` (
  `id` int(11) NOT NULL,
  `marque` varchar(20) DEFAULT NULL,
  `prix` int(11) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `thermomètre`
--

INSERT INTO `thermomètre` (`id`, `marque`, `prix`, `type`) VALUES
(1, 'physio logic', 6, 'rectale'),
(2, 'uline', 40, 'frontale'),
(3, 'geratherm', 13, 'tomporale'),
(4, 'physio logic', 25, 'axillaire');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `thermomètre`
--
ALTER TABLE `thermomètre`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
