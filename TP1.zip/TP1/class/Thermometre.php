<?php
require_once "Produit.php";
class Thermometre extends Produit{
    public $type;


   public function getThermometre($id){
    global $oPDO;
    //preparation de la requette
    $oPDOStatement = $oPDO -> prepare(
      'SELECT id,marque,prix,type FROM thermomètre WHERE id = :id');
      $oPDOStatement -> bindParam(':id',$id,PDO::PARAM_INT);
    //execution de la requete preparee
    $oPDOStatement -> execute();
    //recuperation des resultat
    $thermo = $oPDOStatement -> fetch(PDO ::FETCH_ASSOC);
    return $thermo;
   }

   public function getThermometres(){
    global $oPDO;
    //preparation de la requette
    $oPDOStatement = $oPDO -> prepare(
      'SELECT id,marque,prix,type FROM thermomètre');
    //execution de la requete preparee
    $oPDOStatement -> execute();
    //recuperation des resultat
    $thermos = $oPDOStatement -> fetchAll(PDO ::FETCH_ASSOC);
    return $thermos;
   }




   public function createThermometre($id,$marque,$prix,$type){

    global $oPDO;
    $oPDOStatement = $oPDO->prepare('INSERT INTO thermomètre(id,marque,prix,type)VALUES(:id,:marque,:prix,:type)');
        $oPDOStatement->bindParam(':id',$id,PDO::PARAM_INT);
        $oPDOStatement->bindParam(':marque',$marque,PDO::PARAM_STR);
        $oPDOStatement->bindParam(':prix',$prix,PDO::PARAM_INT);
        $oPDOStatement->bindParam(':type',$type,PDO::PARAM_STR);
      //execution de la requete preparee
      $oPDOStatement -> execute();
      //recuperation des resultat
      $thermo = $oPDOStatement -> fetch(PDO::FETCH_ASSOC);
      return $thermo;
   }

   public function UpdateThermometre($id,$data){
  
    global $oPDO;
    //preparation de la requete
 
    $oPDOStatement = $oPDO->prepare( 'UPDATE  thermomètre SET marque=:marque,prix=:prix,type=:type FROM thermomètre WHERE id = :id');
    $oPDOStatement->bindPARAM(':id',$id,PDO::PARAM_INT);
    $oPDOStatement->bindPARAM(':marque',$data['marque'],PDO::PARAM_STR);
    $oPDOStatement->bindPARAM(':prix',$data['prix'],PDO::PARAM_INT);
    $oPDOStatement->bindPARAM(':type',$data['type'],PDO::PARAM_STR);
    

   
     //execution de la requete preparee
    
    $result = $oPDOStatement -> execute();

     return $result;


    }
    public function deleteThermometre($id){
        global $oPDO;
        $oPDOStatement = $oPDO->prepare('DELETE FROM thermomètre WHERE id = :id');
            $oPDOStatement->bindParam(':id',$id,PDO::PARAM_INT);
          //execution de la requete preparee
         
         
          $result = $oPDOStatement -> execute();
    
          return $result;
       }


       public function getThermometreByMarque($marque){
        global $oPDO;
        //preparation de la requette
        $oPDOStatement = $oPDO -> prepare(
          'SELECT id,marque,prix,type FROM thermomètre WHERE marque = :marque');
          $oPDOStatement -> bindParam(':marque',$marque,PDO::PARAM_STR);
        //execution de la requete preparee
        $oPDOStatement -> execute();
        //recuperation des resultat
        $thermos = $oPDOStatement -> fetchAll(PDO ::FETCH_ASSOC);
        return $thermos;
       }
}
?>