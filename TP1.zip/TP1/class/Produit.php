<?php
class Produit{
    public  $id;
    public  $marque;
    public  $prix;


    public function getProduit($id){
   return  $this->id."/".$this->marque."/".$this->prix;
    }

public function createProduit($id,$marque,$prix){
    $this->id = $id;
    $this->marque = $marque;
    $this->prix = $prix;
    return; 
}
public function updatProduit(){
    $this->id = $id;
    $this->marque = $marque;
    $this->prix = $prix;
    return;
}
public function deleteProduit(){
    $this->id = 0;
    $this->marque = "";
    $this->prix = 0.0;
    return;
}
}


?>